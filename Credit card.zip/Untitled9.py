#!/usr/bin/env python
# coding: utf-8

# In[3]:


import os
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn import preprocessing
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')
import seaborn as sns


# In[4]:


os.chdir("C:/Users/Arun/Downloads")
df = pd.read_csv("credit card data.csv")
df.describe()


# In[5]:


print("Data Types:", df.dtypes)


# In[7]:


df.shape


# In[24]:


df.apply(lambda x: sum(x.isnull()/len(df)))


# In[10]:


missing = df.apply(lambda x:x.fillna(x.value_counts().index[0]))
missing


# In[19]:


plt.boxplot(df['BALANCE'])


# In[20]:


cnames = ['BALANCE', 'BALANCE_FREQUENCY', 'PURCHASES', 'ONEOFF_PURCHASES', 'INSTALLMENTS_PURCHASES', 'CASH_ADVANCE', 'PURCHASES_FREQUENCY', 'ONEOFF_PURCHASES_FREQUENCY', 'PURCHASES_INSTALLMENTS_FREQUENCY', 'CASH_ADVANCE_FREQUENCY', 'CASH_ADVANCE_TRX', 'PURCHASES_TRX', 'PAYMENTS', 'PRC_FULL_PAYMENT', 'TENURE', 'CREDIT_LIMIT', 'MINIMUM_PAYMENTS']
for i in cnames:
    q75, q25 = np.percentile(df.loc[:, i], [75, 25])
    iqr = q75 - q25
    print(i)
    
    min = q25 - (iqr*1.5)
    max = q75 + (iqr*1.5)
    print(min)
    print(max)
    
    df = df.drop(df[df.loc[:,i] < min].index)
    df = df.drop(df[df.loc[:,i] > max].index)


# In[21]:





# In[26]:


x = missing.values
min_max_scaler = preprocessing.MinMaxScaler()
x_scaled = min_max_scaler.fit_transform(x)
missing = pd.DataFrame(x_scaled,columns=missing.columns)


# In[27]:


missing


# In[28]:


Sum_of_squared_distances = []
K = range(1,15)
for k in K:
    km = KMeans(n_clusters=k)
    km = km.fit(missing)
    Sum_of_squared_distances.append(km.inertia_)
plt.plot(K, Sum_of_squared_distances, 'bx-')
plt.xlabel('k')
plt.ylabel('Sum_of_squared_distances')
plt.title('Elbow Method For Optimal k')
plt.show()


# In[29]:


np.random.seed(0)
msk = np.random.rand(len(missing)) < 0.8
train = missing[msk]
test = missing[~msk]


# In[31]:


test


# In[32]:


X = np.array(train)
X_test = np.array(test)


# In[33]:


X_test


# In[34]:


kmeans = KMeans(n_clusters=8, random_state=0).fit(X)


# In[35]:


kmeans


# In[36]:


k = kmeans.predict(X_test)


# In[37]:


k


# In[38]:


train_summary = test.groupby(by='PREDICTED_CLUSTER').mean()
train_summary = train_summary[['BALANCE', 'PURCHASES', 'PURCHASES_FREQUENCY','CREDIT_LIMIT', 'ONEOFF_PURCHASES_FREQUENCY', 'MINIMUM_PAYMENTS','PRC_FULL_PAYMENT', 'PAYMENTS']]


# In[ ]:




