rm(list=ls())
setwd("C:/Users/Arun/Downloads")
getwd()
x = c("ggplot2", "corrgram", "DMwR", "caret", "randomForest", "unbalanced", "C50", "dummies", "e1071", "Information",
+       "MASS", "rpart", "gbm", "ROSE", 'sampling', 'DataCombine', 'inTrees')
install.packages(x)
df = read.csv("credit card data.csv", header = T, na.strings = c(" ", "", "NA"))
str(df)
missing = data.frame(apply(df,2,function(x){sum(is.na(x))}))
missing$Columns = row.names(missing)
names(missing)[1] =  "Missing_percentage"
missing$Missing_percentage = (missing$Missing_percentage/nrow(df)) * 100
missing = missing[order(-missing$Missing_percentage),]
row.names(missing) = NULL
missing = missing[,c(2,1)]
ggplot(data = missing_val[1:3,], aes(x=reorder(Columns, -Missing_percentage),y = Missing_percentage))+
geom_bar(stat = "identity",fill = "grey")+xlab("Parameter")+
ggtitle("Missing data percentage (Train)") + theme_bw()
df$custAge[is.na(df$custAge)] = mean(df$custAge, na.rm = T)
numeric_index = sapply(df,is.numeric) #selecting only numeric

numeric_data = df[,numeric_index]

cnames = colnames(numeric_data)
for (i in 1:length(cnames))
{
assign(paste0("gn",i), ggplot(aes_string(y = (cnames[i]), x = "responded"), data = subset(marketing_train))+ 
stat_boxplot(geom = "errorbar", width = 0.5) +
geom_boxplot(outlier.colour="red", fill = "grey" ,outlier.shape=18,
outlier.size=1, notch=FALSE) +
theme(legend.position="bottom")+
labs(y=cnames[i],x="responded")+
ggtitle(paste("Box plot of responded for",cnames[i])))
gridExtra::grid.arrange(gn1,gn5,gn2,ncol=3)
gridExtra::grid.arrange(gn6,gn7,ncol=2)
gridExtra::grid.arrange(gn8,gn9,ncol=2)
val = df$previous[df$previous %in% boxplot.stats(df$previous)$out]
df = df[which(!df$previous %in% val),]
for(i in cnames){
print(i)
val = df[,i][df[,i] %in% boxplot.stats(df[,i])$out]
print(length(val))
df = df[which(!df[,i] %in% val),]
}
cnames = c("custAge","campaign","previous","cons.price.idx","cons.conf.idx","euribor3m","nr.employed",
           "pmonths","pastEmail")

for(i in cnames){
  print(i)
  df[,i] = (df[,i] - min(df[,i]))/
    (max(df[,i] - min(df[,i])))
}

mean(NB_Predictions == test$responded)
irisCluster <- kmeans(train[,1:16], 2, nstart = 20)
table(irisCluster$cluster, train$responded)

  




